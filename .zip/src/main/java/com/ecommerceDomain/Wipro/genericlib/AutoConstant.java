package com.ecommerceDomain.Wipro.genericlib;
/**
 * 
 * @author sabar
 *
 */
public interface AutoConstant {
	/*
	 * it is used to store all the constants
	 */
String Datapropertyfile="./src/test/resources/Data.properties";
String excelfilepath=".src/text/resources/Book1.xlsx";
String photoPath="./photo/";
String reportpath="./reports/skilllrareoprt.html";
}
